<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSalariesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('salaries', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->longText('emp_id');
            $table->longText('branch_id1');
            $table->longText('salary1');
            $table->longText('branch_id2')->nullable();
            $table->longText('salary2')->nullable();
            $table->longText('branch_id3'->nullable());
            $table->longText('salary3')->nullable();
            $table->longText('total_salary');
            $table->longText('created_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('salaries');
    }
}
