<?php $__env->startSection("content"); ?>

        <!-- BREADCRUMBS AREA START -->
        <div class="breadcrumbs-area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="breadcrumbs">
                            <h1 class="breadcrumbs-title">ETP Protective Coating In Bangladesh</h1>
                            <ul class="breadcrumbs-list">
                                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <li>ETP Protective Coating</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- BREADCRUMBS AREA END -->

        <!-- Start page content -->
        <section id="page-content" class="page-wrapper">

            <!-- PROPERTIES DETAILS AREA START -->
            <div class="properties-details-area pt-115 pb-60">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <!-- pro-details-image -->
                            <div class="pro-details-image mb-60">
                                <div class="pro-details-big-image">
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane fade in active" id="pro-1">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/ETP-Protective-Coating01.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 1">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/ETP-Protective-Coating01.jpg')); ?>" alt="ETP Protective Coating In Bangladesh">
                                            </a>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="pro-2">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/ETP-Protective-Coating02.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 2">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/ETP-Protective-Coating02.jpg')); ?>" alt="ETP Protective Coating In Bangladesh">
                                            </a>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="pro-3">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/ETP-Protective-Coating03.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 3">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/ETP-Protective-Coating03.jpg')); ?>" alt="ETP Protective Coating In Bangladesh">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="pro-details-carousel">
                                    <div class="pro-details-item">
                                        <a href="#pro-1" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/ETP-Protective-Coating01.jpg')); ?>" alt="ETP Protective Coating In Bangladesh"></a>
                                    </div>
                                    <div class="pro-details-item">
                                        <a href="#pro-2" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/ETP-Protective-Coating02.jpg')); ?>" alt="ETP Protective Coating In Bangladesh">                
                                        </a>
                                    </div>
                                    <div class="pro-details-item">
                                        <a href="#pro-3" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/ETP-Protective-Coating03.jpg')); ?>" alt="ETP Protective Coating In Bangladesh">                
                                        </a>
                                    </div>
                                </div>                           
                            </div>
                            <!-- pro-details-description -->
                            <div class="pro-details-description mb-50">
                              <h2>ETP Protective Coating in Bangladesh</h2>
                                <p class="text-justify">Falcon Solution Ltd's extensive range of protective coatings has provided to the highest quality standards on durable & sustainable technology has stood time tested the protection of the structures all over Bangladesh. Falcon Solution Ltd providing the best service for Etp protective coating in Bangladesh as the best applicator as well as a contractor at affordable prices. We are also providing the best service for Epoxy flooring, floor hardener, waterproofing, Vinyl flooring, Polished concrete & <a href="<?php echo e(URL::to('pu-flooring-in-bangladesh')); ?>">PU flooring in Bangladesh.</a></p>
                                <p class="text-justify">Utilizing our extensive range of products, combined with expert knowledge and experience of our people, from buildings to bridges and primary & secondary concrete containment. Falcon Solution Ltd can assist you to achieve the best protective coating solution for your project.</p>
                                <strong>Benefits:</strong>
                                <ul class="">
                                    <li>Protect ETP structure from deterioration</li>
                                    <li>Capable to tolerate maximum 400 degree Fahrenheit</li>
                                    <li>Durable, long lasting and trusted product specially chemical treatment tank</li>
                                    <li>Green certified and low volatile organic compound (VOC) products</li>
                                    <li>Certified by Accord Board</li>
                                    <li>Economical and low maintenance cost</li>
                                    <li>Unique and beautiful looking environment</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <!-- widget-featured-property -->
                            <aside class="widget widget-featured-property">
                                <h5>Another Services</h5>
                                <div class="row">
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('pu-flooring-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/pu-flooring.jpg')); ?>" alt="PU Flooring In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('pu-flooring-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>PU Flooring Solution</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('epoxy-flooring-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/epoxy-flooring.jpg')); ?>" alt="Epoxy Flooring In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('epoxy-flooring-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>Epoxy Flooring Solution</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 hidden-sm col-xs-12">
                                        <div class="flat-item">
                                            <div class="flat-item-image">
                                                <a href="<?php echo e(URL::to('polished-concrete-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/polished-concrete.jpg')); ?>" alt="Polished Concrete In Bangladesh"></a>
                                                <div class="flat-link">
                                                    <a href="<?php echo e(URL::to('polished-concrete-in-bangladesh')); ?>">More Details</a>
                                                </div>
                                                <ul class="flat-desc">
                                                    <li>
                                                        <span>Polished Concrete</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('waterproofing-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/waterproofing.jpg')); ?>" alt="Waterproofing In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('waterproofing-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>Waterproofing Solution</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
            <!-- PROPERTIES DETAILS AREA END -->
        </section>
        <!-- End page content -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/frontend/main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/falconso/public_html/resources/views/main/frontend/etp_protective_coating.blade.php ENDPATH**/ ?>