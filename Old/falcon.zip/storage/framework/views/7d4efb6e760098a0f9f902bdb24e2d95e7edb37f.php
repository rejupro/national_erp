<?php $__env->startSection("content"); ?>
        <!-- BREADCRUMBS AREA START -->
        <div class="breadcrumbs-area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="breadcrumbs">
                            <h1 class="breadcrumbs-title">Crack Repair Injection Systems In Bangladesh</h1>
                            <ul class="breadcrumbs-list">
                                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <li>Crack Repair Injection Systems</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- BREADCRUMBS AREA END -->

        <!-- Start page content -->
        <section id="page-content" class="page-wrapper">

            <!-- PROPERTIES DETAILS AREA START -->
            <div class="properties-details-area pt-115 pb-60">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <!-- pro-details-image -->
                            <div class="pro-details-image mb-60">
                                <div class="pro-details-big-image">
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane fade in active" id="pro-1">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals01.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 1">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals01.jpg')); ?>" alt="Crack Repair Injection Systems In Bangladesh">
                                            </a>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="pro-2">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals02.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 2">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals02.jpg')); ?>" alt="Crack Repair Injection Systems In Bangladesh">
                                            </a>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="pro-3">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals03.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 3">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals03.jpg')); ?>" alt="Crack Repair Injection Systems In Bangladesh">
                                            </a>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="pro-4">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals04.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 4">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals04.jpg')); ?>" alt="Crack Repair Injection Systems In Bangladesh">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="pro-details-carousel">
                                    <div class="pro-details-item">
                                        <a href="#pro-1" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/Construction-Chemicals01.jpg')); ?>" alt="Crack Repair Injection Systems In Bangladesh"></a>
                                    </div>
                                    <div class="pro-details-item">
                                        <a href="#pro-2" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/Construction-Chemicals02.jpg')); ?>" alt="Crack Repair Injection Systems In Bangladesh">                
                                        </a>
                                    </div>
                                    <div class="pro-details-item">
                                        <a href="#pro-3" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/Construction-Chemicals03.jpg')); ?>" alt="Crack Repair Injection Systems In Bangladesh">                
                                        </a>
                                    </div>
                                    <div class="pro-details-item">
                                        <a href="#pro-4" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/Construction-Chemicals04.jpg')); ?>" alt="Crack Repair Injection Systems In Bangladesh">                
                                        </a>
                                    </div>
                                </div>                           
                            </div>
                            <!-- pro-details-description -->
                            <div class="pro-details-description mb-50">
                              <h2>Crack Repair Injection Systems in Bangladesh</h2>
                                <p class="text-justify">Our considerably developed crack repair injection theme is supposed to push water away and to boot permanently restore structural power to concrete. The use of our injection systems deliver superior solutions to cracks in concrete basements, foundation walls, and structures.</p>

                                <p class="text-justify">Our expressed epoxy system is supposed to stop concrete deterioration at the crack, though protecting the steel reinforcement at intervals the jammed area. The organic compound injection compound performances to push water away to facilitate the waterproofing of cracks in basement walls. Our theme may restore structural strength to the house, though protecting the within method from incoming water, air, and bugs.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <!-- widget-featured-property -->
                            <aside class="widget widget-featured-property">
                                <h5>Another Services</h5>
                                <div class="row">
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('pu-flooring-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/pu-flooring.jpg')); ?>" alt="PU Flooring In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('pu-flooring-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>PU Flooring Solution</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('epoxy-flooring-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/epoxy-flooring.jpg')); ?>" alt="Epoxy Flooring In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('epoxy-flooring-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>Epoxy Flooring Solution</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 hidden-sm col-xs-12">
                                        <div class="flat-item">
                                            <div class="flat-item-image">
                                                <a href="<?php echo e(URL::to('polished-concrete-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/polished-concrete.jpg')); ?>" alt="Polished Concrete In Bangladesh"></a>
                                                <div class="flat-link">
                                                    <a href="<?php echo e(URL::to('polished-concrete-in-bangladesh')); ?>">More Details</a>
                                                </div>
                                                <ul class="flat-desc">
                                                    <li>
                                                        <span>Polished Concrete</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('waterproofing-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/waterproofing.jpg')); ?>" alt="Waterproofing In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('waterproofing-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>Waterproofing Solution</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
            <!-- PROPERTIES DETAILS AREA END -->
        </section>
        <!-- End page content -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/frontend/main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/falconso/public_html/resources/views/main/frontend/crack_repair_injection_systems.blade.php ENDPATH**/ ?>