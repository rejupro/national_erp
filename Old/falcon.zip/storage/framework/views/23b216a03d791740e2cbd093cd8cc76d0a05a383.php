﻿
<?php $__env->startSection("content"); ?>

        <!-- BREADCRUMBS AREA START -->
        <div class="breadcrumbs-area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="breadcrumbs">
                            <h1 class="breadcrumbs-title">Concrete Auxiliaries In Bangladesh</h1>
                            <ul class="breadcrumbs-list">
                                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <li>Concrete Auxiliaries</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- BREADCRUMBS AREA END -->

        <!-- Start page content -->
        <section id="page-content" class="page-wrapper">

            <!-- PROPERTIES DETAILS AREA START -->
            <div class="properties-details-area pt-115 pb-60">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <!-- pro-details-image -->
                            <div class="pro-details-image mb-60">
                                <div class="pro-details-big-image">
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane fade in active" id="pro-1">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals01.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 1">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals01.jpg')); ?>" alt="Concrete Auxiliaries In Bangladesh">
                                            </a>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="pro-2">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals02.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 2">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals02.jpg')); ?>" alt="Concrete Auxiliaries In Bangladesh">
                                            </a>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="pro-3">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals03.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 3">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals03.jpg')); ?>" alt="Concrete Auxiliaries In Bangladesh">
                                            </a>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="pro-4">
                                            <a href="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals04.jpg')); ?>" data-lightbox="image-1" data-title="Sheltek Properties - 4">
                                                <img src="<?php echo e(asset('public/front/images/single-property/big/Construction-Chemicals04.jpg')); ?>" alt="Concrete Auxiliaries In Bangladesh">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="pro-details-carousel">
                                    <div class="pro-details-item">
                                        <a href="#pro-1" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/Construction-Chemicals01.jpg')); ?>" alt="Concrete Auxiliaries In Bangladesh"></a>
                                    </div>
                                    <div class="pro-details-item">
                                        <a href="#pro-2" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/Construction-Chemicals02.jpg')); ?>" alt="Concrete Auxiliaries In Bangladesh">                
                                        </a>
                                    </div>
                                    <div class="pro-details-item">
                                        <a href="#pro-3" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/Construction-Chemicals03.jpg')); ?>" alt="Concrete Auxiliaries In Bangladesh">                
                                        </a>
                                    </div>
                                    <div class="pro-details-item">
                                        <a href="#pro-4" data-toggle="tab">
                                            <img src="<?php echo e(asset('public/front/images/single-property/small/Construction-Chemicals04.jpg')); ?>" alt="Concrete Auxiliaries In Bangladesh">                
                                        </a>
                                    </div>
                                </div>                           
                            </div>
                            <!-- pro-details-description -->
                            <div class="pro-details-description mb-50">

                                <h2>Concrete Auxiliaries in Bangladesh</h2>
                                <p class="text-justify">Falcon Solution Ltd auxiliaries' merchandise fulfill totally different needs e. g. terribly high compressive power, short activity time, high adhesive tensile power and additionally water tightness. Looking on the precise application, mortar merchandise may well be picked from the massive Falcon Solution Ltd vary that have the required combination of chemical characteristics. In some cases, admixtures are accustomed improve special properties of the concrete. Since it's our need to supply you every merchandise essential to attach building systems from one supply, we have a tendency to forever provide special additives to induce good final results on-site.</p>

                                <p class="text-justify">Concrete wants well outlined physical chemical properties. This is often the explanation why Falcon Solution Ltd is manufacturing additives meant to progress the standard of concrete performance at every phases to extend the standard of the tip product and environmental impact. Management of runniness, times, setting, amount and quality of enclosed air are a number of the stuffs we have a tendency to request to advocate and additionally develop within the Construction business. The road of goods of merchandise for concrete consists of the elemental products not combinetures essential to realize top quality additives and the simplest value profit quantitative relation for application of prepared mix and additionally pre-cast concrete. </p>

                                <p class="text-justify">Our product are characterized by continuous innovations, like the explore for merchandise that increase the workability of additive-enhanced concrete, exploitation sorts of workability extenders, that would be mixed with additives already accessible on the market. Another innovation is that the continuous explore for additives, not solely within the liquid type, however additionally powder and granules, for various forms of applications therefore on extend the vary of products and additionally higher answer our clients queries. </p>

                                <p class="text-justify">We still operate with different companies in enhancing our vary of merchandise and additionally, especially, within the growth of latest additives. To boot, over the years, Falcon Solution Ltd has cooperated with totally different universities within the explore for innovative solutions and additionally the presentation of scientific articles at many congresses, even international.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <!-- widget-featured-property -->
                            <aside class="widget widget-featured-property">
                                <h5>Another Services</h5>
                                <div class="row">
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('pu-flooring-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/pu-flooring.jpg')); ?>" alt="PU Flooring In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('pu-flooring-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>PU Flooring Solutions</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('epoxy-flooring-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/epoxy-flooring.jpg')); ?>" alt="Epoxy Flooring In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('epoxy-flooring-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>Epoxy Flooring Solutions</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 hidden-sm col-xs-12">
                                        <div class="flat-item">
                                            <div class="flat-item-image">
                                                <a href="<?php echo e(URL::to('polished-concrete-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/polished-concrete.jpg')); ?>" alt="Polished Concrete In Bangladesh"></a>
                                                <div class="flat-link">
                                                    <a href="<?php echo e(URL::to('polished-concrete-in-bangladesh')); ?>">More Details</a>
                                                </div>
                                                <ul class="flat-desc">
                                                    <li>
                                                        <span>Polished Concrete</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- flat-item -->
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                      <div class="flat-item">
                                          <div class="flat-item-image">
                                              <a href="<?php echo e(URL::to('waterproofing-in-bangladesh')); ?>"><img src="<?php echo e(asset('public/front/images/flat/waterproofing.jpg')); ?>" alt="Waterproofing In Bangladesh"></a>
                                              <div class="flat-link">
                                                  <a href="<?php echo e(URL::to('waterproofing-in-bangladesh')); ?>">More Details</a>
                                              </div>
                                              <ul class="flat-desc">
                                                  <li>
                                                      <span>Waterproofing Solutions</span>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
            <!-- PROPERTIES DETAILS AREA END -->
        </section>
        <!-- End page content -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/frontend/main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/falconso/public_html/resources/views/main/frontend/concrete_auxiliaries.blade.php ENDPATH**/ ?>