<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_delivery extends Model
{
    protected $table = 'product_deliverys';
}
