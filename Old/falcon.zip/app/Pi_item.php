<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pi_item extends Model
{
    protected $table = 'pi_items';
}
