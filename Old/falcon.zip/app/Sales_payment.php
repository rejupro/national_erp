<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sales_payment extends Model
{
    //
}
