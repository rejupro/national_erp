<?php

namespace App\Http\Controllers\DailyProcess;

use App\DailyExpenseModel;
use App\DailyExpenseModelDetails;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Designation;
use App\Employee;

use App\Product;
use App\Project;
use App\Requisition;
use App\Expensehead;
use App\PaymentVaucher;
use App\Unit;

use DB;
use Validator;
use Carbon\Carbon;

class DailyExpenseController extends Controller
{
    public function index()
    {
        // if(Auth::User()->brand_id==1){
           $expenses = DailyExpenseModel::with(['project','staff'])->get();
        //    dd($expenses->toArray());
        // }else{
            // $expenses = DailyExpenseModel::with(['project','staff'])->where('bid',Auth::User()->brand_id)->get();
        // }
        return view('main.admin.dailyprocess.daily_expense_list',compact('expenses'));
    }
    public function create()
    {
        $projects = Project::get();
        $code = 'REQ-NO-' . Requisition::get()->max('id');
        $employees = Employee::get();
        $expenses = Expensehead::get();
        $designations = Designation::get();
        $products = Product::get();
        $unit = Unit::get();
        $pay_vaucher = PaymentVaucher::get();
        // dd($pay_vaucher->toArray());
        return view('main.admin.dailyprocess.daily_expense_create',compact('pay_vaucher','projects','employees','designations','products','unit','code','expenses'));
    }
    public function store(Request $request)
    {
        try {
            // dd($request->all());
        if($request->ajax())
        {
            $rules = array(
                'project_id' => 'required',
                'requisition_item.*'  => 'required',
                'price.*'  => 'required'
            );
            $error = Validator::make($request->all(), $rules);
            if($error->fails())
            {
                return response()->json([
                    'error'  => $error->errors()->all()
                ]);
            }

            $insert=DailyExpenseModel::create([
                'project_id' =>  $request->project_id,
                'date' =>  date('Y-m-d', strtotime($request->date)),
                'pay_vaucher_id' => $request->pay_vaucher_id,
                'amount' => $request->amount,
                'balance' => $request->balance,
                'stf_id' =>  $request->stf_id ? $request->stf_id: null,
                'address' =>  $request->address,
                'grand_total' =>  $request->total,
            ]);

            
            $daily_expense_model_id =$insert->id;
            $requisition_item = $request->requisition_item;
            $unit_id = $request->unit_id;
            $qty = $request->qty;
            $price = $request->price;
            $nprice = $request->nprice;
            for($count = 0; $count < count($requisition_item); $count++)
            {
            $data = array(
                'requisition_item' => $requisition_item[$count],
                'unit_id'  => $unit_id[$count],
                'qty' => $qty[$count],
                'price'  => $price[$count],
                'nprice'  => $nprice[$count],
                'daily_expense_model_id' => $daily_expense_model_id
            );
            $insert_data[] = $data;
            }
            // dd($insert_data);
            DailyExpenseModelDetails::insert($insert_data);
            return response()->json([
                'success'  => 'Data Added successfully.'
            ]);
            }
            return redirect(route('daily-expense-create-route'));
        } catch (\Exception $error) {
            dd($error->getMessage());
        }
    }
    public function view($id)
    {
        $expenses = DailyExpenseModel::with(['project','staff'])->get();
        $details = DailyExpenseModelDetails::with('unit')->where('daily_expense_model_id', '=', $id)->get();
        $list = DB::table('daily_expense_models')->get();
        // dd( $details->toArray());
        return view('main.admin.dailyprocess.daily_expense_view',compact('expenses','details','list'));
    }
    public function getAmount($id)
    {
        $data = PaymentVaucher::where('id',$id)->first();
        // dd($data->toArray());
        return response()->json($data);
    }
}
