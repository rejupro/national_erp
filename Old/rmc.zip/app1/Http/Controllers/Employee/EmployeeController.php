<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Redirect;
use Datatables;
use Carbon\Carbon;
use App\Employee;
use App\Department;
use App\Designation;
use App\Branch;
use DB;
use Auth;

class EmployeeController extends Controller
{
    public function employee_index()
    {

        if(Auth::User()->brand_id==1){
            $data = Employee::with(['department','designation','branch'])->get();
          }else{
            $data = Employee::where('wbrid',Auth::User()->brand_id)->with(['department','designation','branch'])->get();
          }
       
        return view('main.admin.payroll.employee_list',compact('data'));
    }

    public function create_page()
    {
        $department=Department::orderBy('dept_name','asc')->get();
        $designation=Designation::orderBy('desg_name','asc')->get();
        $branch=Branch::orderBy('name','asc')->get();
        return view('main.admin.payroll.employee_create',compact('designation','department','branch'));
    }

    public function employee_store(Request $request)
    {

        $brid= Auth::User()->brand_id;
        $uid = Auth::User()->id;
        $request->validate([
            'name'   => 'required|string',
            'join_date'   => 'required|string',
            'salary'   => 'required|string|numeric',
            'status'   => 'required|string',
            'wbrid'   => 'required',
            'item'   => 'mimes:jpeg,jpg,png,svg,jpeg,JPEG,PNG,JPG'
        ]);
        $data = new Employee();
        $input = $request->all();
        $input['uid']= $uid;
        $input['brid']= $brid;
        $image=$request->file('item');
        if ($image) {
            $image_name=hexdec(uniqid());
            $ext=strtolower($image->getClientOriginalExtension());
            $image_full_name=$image_name.'.'.$ext;
            $upload_path='Upload/Employee/';
            $image_url=$upload_path.$image_full_name;
            $success=$image->move($upload_path,$image_full_name);
            $input['item']=$image_url;
            $input['created_by']='';
            $data->fill($input)->save();
        return Redirect::back()->withErrors(['Data Added Successfully...!!!']);
        }
        else{
            $input['created_by']='';
            $data->fill($input)->save();   
            return Redirect::back()->withErrors(['Data Added Successfully...!!!']);
        }
    }

    public function edit_page($id)
    {
        $data = DB::table('employees')
        ->join('departments','departments.id','=','employees.dept_id')
        ->join('designations','designations.id','=','employees.desg_id')
        ->join('branches','branches.id','=','employees.wbrid')
        ->where('employees.id',$id)
        ->select('employees.*','departments.dept_name','designations.desg_name','branches.name as br_name')
        ->first();
        $department=Department::orderBy('dept_name','asc')->get();
        $designation=Designation::orderBy('desg_name','asc')->get();
        $branch=Branch::orderBy('name','asc')->get();
        return view('main.admin.payroll.employee_edit',compact('data','designation','department','branch'));
    }

    public function update_store(Request $request,$id)
    {
        $data = Employee::findOrFail($id);
        $input = $request->all();
        $image=$request->file('item');
        if ($image) {
            $image_name=hexdec(uniqid());
            $ext=strtolower($image->getClientOriginalExtension());
            $image_full_name=$image_name.'.'.$ext;
            $upload_path='Upload/Employee/';
            $image_url=$upload_path.$image_full_name;
            $success=$image->move($upload_path,$image_full_name);
            $input['item']=$image_url;
            $input['created_by']='';
        $data->update($input);
        return Redirect::back()->withErrors(['Data Updated Successfully...!!!']);
        }
        else{
        $data = Employee::findOrFail($id);
        $input = $request->all();
        $input['item']=$data->item;
        $input['created_by']='';
        $data->update($input);
        return Redirect::back()->withErrors(['Data Updated Successfully...!!!']);
        }
    }

    public function Employee_destroy($id)
    {
        $data=Employee::findOrfail($id);
        $data->delete();
        return Redirect::back()->withErrors(['Data Deleted Successfully...!!!']);
    }
}
