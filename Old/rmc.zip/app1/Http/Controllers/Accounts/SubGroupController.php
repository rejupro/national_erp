<?php

namespace App\Http\Controllers\Accounts;

use App\Group;
use App\Http\Controllers\Controller;
use App\SubGroup;
use Illuminate\Http\Request;
use Auth;

class SubGroupController extends Controller
{
    public function index()
    {
        if(Auth::User()->brand_id==1){
            $subgroups = SubGroup::with(['group'])->get();
        }else{
            $subgroups = SubGroup::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->with(['group'])->get();
        }
       
       
        return view('main.admin.accounts.subgrouplist',compact('subgroups'));
    }

    public function create()
    {

        if(Auth::User()->brand_id==1){
            $groups=Group::get();
        }else{
            $groups=Group::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }


        $subgroup = SubGroup::get();
        
        return view('main.admin.accounts.subgroupcreate',compact('groups','subgroup'));
    }

    public function store(Request $request)
    {
        $brid= Auth::User()->brand_id;
        $uid = Auth::User()->id;
        $data = new SubGroup();
        $input = $request->all();
        $input['brid']= $brid;
        $input['uid']= $uid;
        $data->fill($input)->save();
           
        return redirect(route('subgroup-list'));
    }
    public function edit($id)
    {
        if(Auth::User()->brand_id==1){
            $groups=Group::get();
        }else{
            $groups=Group::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        $subgroup = SubGroup::find($id);
        return view('main.admin.accounts.subgroupedit',compact('groups','subgroup'));
    }

    public function update(Request $request,$id)
    {
        $subgroup = SubGroup::findOrFail($id);
        $subgroup->update($request->all());
        return redirect(route('subgroup-list'));
    }
    public function destroy($id)
    {
        $subgroup = SubGroup::findOrFail($id);
        $subgroup->delete();
        // dd($group);
        return redirect(route('subgroup-list'))->with('messages','successfully');
    }

}
