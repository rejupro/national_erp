<?php

namespace App\Http\Controllers\Accounts;

use App\AccountClass;
use App\Group;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;

class GroupController extends Controller
{
    public function index()
    {
        if(Auth::User()->brand_id==1){
            $groups=Group::with(['class'])->get();
        }else{
            $groups=Group::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->with(['class'])->get();
        }

        return view('main.admin.accounts.grouplist',compact('groups'));
    }

    public function create()
    {
        $class = AccountClass::get();
        $results = 'GRP-NO-00' . Group::get()->max('id');
        // dd($account_classes->toArray());
        return view('main.admin.accounts.groupcreate',compact('class','results'));
    }

    public function store(Request $request)
    {
           // dd($request->all());
           $brid= Auth::User()->brand_id;
           $uid = Auth::User()->id;
           $data = new Group();
           $input = $request->all();
           $input['brid']= $brid;
           $input['uid']= $uid;
           $data->fill($input)->save();
           return redirect(route('acc-group-list'));
    }

    public function edit($id)
    {
        $group = Group::find($id);
        $account_classes = AccountClass::get();
        return view('main.admin.accounts.groupedit',compact('group','account_classes'));
    }

    public function update(Request $request,$id)
    {
        $group = Group::findOrFail($id);
        $group->update($request->all());
        return redirect(route('acc-group-list'));
    }
    public function destroy($id)
    {
        $group = Group::findOrFail($id);
        $group->delete();
        // dd($group);
        return redirect(route('acc-group-list'))->with('messages','successfully');
    }
}
