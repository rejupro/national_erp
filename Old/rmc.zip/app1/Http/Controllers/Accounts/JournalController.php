<?php

namespace App\Http\Controllers\Accounts;

use App\Http\Controllers\Controller;
use App\JournalVoucher;
use App\JournalVoucherDetail;
use App\Ledger;
use App\Project;
use App\SubGroup;
use Illuminate\Http\Request;
use DB;
use Auth;

class JournalController extends Controller
{
    public function index()
    {

        if(Auth::User()->brand_id==1){ 
            $journal = JournalVoucherDetail::with(['journals.projects'])->get();
          }else{
            $journal = JournalVoucherDetail::where('brid',Auth::User()->brand_id)->with(['journals.projects'])->get();
          }
      
        
        return view('main.admin.accounts.jour_list',compact('journal'));
    }
    public function create()
    {
        if(Auth::User()->brand_id==1){
            $projects = Project::get();
          }else{
              $projects = Project::where('brid',Auth::User()->brand_id)->get();
        }
        $sub_groups = SubGroup::get();
        $ledgers = Ledger::get();
        $jur_track = 'JUR-VNO-' . JournalVoucherDetail::get()->max('id');
        return view('main.admin.accounts.jour_create',compact('projects','sub_groups','ledgers','jur_track'));
    }
    public function store(Request $request)
    {

        if($request->ajax())
        {
        // dd($request->all());
        $user_id=Auth::User()->id;
        $brid=Auth::User()->brand_id;
        $data = $request->except('_token', 'debit_sub_group_id', 'debit_ledger_id', 'debit_amount', 'credit_ledger_id', 'credit_sub_group_id','cheque_no','cheque_date','ref');
        $data['uid']=$user_id;
        $data['brid']=$brid;
        $result = JournalVoucher::create($data);
        // dd($request->debit_sub_group_id);

        foreach($request->debit_sub_group_id as $key => $value):
            $details[] = [
                'journal_voucher_id' => $result->id,
                'debit_ledger_id' => $request->debit_ledger_id[$key],
                'debit_sub_group_id' => $request->debit_sub_group_id[$key],
                'debit_amount' => $request->debit_amount[$key],
                'credit_ledger_id' => $request->credit_ledger_id[$key],
                'credit_sub_group_id' => $request->credit_sub_group_id[$key],
                'cheque_no' => $request->cheque_no[$key],
                'cheque_date' => $request->cheque_date[$key],
                'ref' => $request->ref[$key],
                'brid'=> $brid
            ];
        endforeach;

        // dd($request->all(),$details);
        JournalVoucherDetail::insert($details);
        return response()->json([
            'success'  => 'Data Added successfully.'
        ]);
        }

    }

    public function show($id)
    {
        $journal = JournalVoucher::with(['projects'])->findOrfail($id);

        $details = JournalVoucherDetail::where('journal_voucher_id' ,'=', $journal->id)->get();
        // $details = JournalVoucherDetail::get();

        // dd($details->toArray());
        return view('main.admin.accounts.jour_view',compact('journal','details'));
    }

    public function destroy($id)
    {
        $data = JournalVoucherDetail::findOrFail($id);
        $data->delete();
        return redirect(route('journal-list'));
    }

    public function find_debit_ledger(Request $request)
    {
        $id= $request->sub_grp_id;
        $ledger=DB::table('ledgers')->where('sub_grp_id',$request->id)->get();
        // dd($id);
        $str = '';
         if ($ledger){
            foreach ($ledger as $result){
                $i=$i+1;
                $str .='<option value="{{$result->id}}"> {{$result->name}} </option>';
                }
            }

        echo $str;
    }
}
