<?php

namespace App\Http\Controllers\Project;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Datatables;
use App\Project;
use App\Progroup;
use App\Prosubgroup;
use App\Protype;
use App\Procontractor;
use App\Customer;
use Redirect;
use Auth;
use DB;

class projectController extends Controller
{
    public function create_project()
    {
        if(Auth::User()->brand_id==1){
          $subgroup = Prosubgroup::orderBy('created_at','desc')->get();
        }else{
          $subgroup = Prosubgroup::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        if(Auth::User()->brand_id==1){
          $group = Progroup::orderBy('created_at','desc')->get();
        }else{
           $group = Progroup::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        if(Auth::User()->brand_id==1){
          $type = Protype::orderBy('created_at','desc')->get();
        }else{
          $type = Protype::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        if(Auth::User()->brand_id==1){
          $contractor = Procontractor::orderBy('created_at','desc')->get();
        }else{
            $contractor = Procontractor::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        if(Auth::User()->brand_id==1){
          $customer=Customer::get();
        }else{
          $customer=Customer::where('brid',Auth::User()->brand_id)->get(); 
        }
        $results = 'PRJ-NO-' . Project::get()->max('id');
        return view('main.admin.manage_project.project_create',compact('results','group','subgroup','type','contractor','customer'));
    }
    public function list_project()
    {
        if(Auth::User()->brand_id==1){
          $project = Project::with(['group','subgroup','type','contractor','customer'])
          ->orderBy('created_at','desc')->get();
        }else{
          $project = Project::with(['group','subgroup','type','contractor','customer'])
          ->where('brid',Auth::User()->brand_id)
          ->orderBy('created_at','desc')->get();
                    
        }
        return view('main.admin.manage_project.project_list',compact('project'));
    	
    }

    public function store_project(Request $request){
    	
        $request->validate([
            
            'project_id' => 'unique:projects'
        ]);
        $brid= Auth::User()->brand_id;
        $uid = Auth::User()->id;
        $data = new Project();
        $input = $request->all();
        $input['brid']= $brid;
        $input['uid']= $uid;
        $data->fill($input)->save();
    	return Redirect::route('project-list-page')->withErrors(['Data Create Successfully...!!!']);
    }
    public function project_edit($id)
    {
        if(Auth::User()->brand_id==1){
          $group = Progroup::orderBy('created_at','desc')->get();
        }else{
          $group = Progroup::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        if(Auth::User()->brand_id==1){
          $subgroup = Prosubgroup::orderBy('created_at','desc')->get();
        }else{
          $subgroup = Prosubgroup::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        if(Auth::User()->brand_id==1){
          $datas= DB::table('prosubgroups')
          ->join('progroups','progroups.id','=','prosubgroups.pgid')
          ->select('progroups.name as pg_name','prosubgroups.*')
          ->get();
        }else{
          $datas= DB::table('prosubgroups')
          ->join('progroups','progroups.id','=','prosubgroups.pgid')
          ->select('progroups.name as pg_name','prosubgroups.*')
          ->where('prosubgroups.brid',Auth::User()->brand_id)
          ->get();
        }
        if(Auth::User()->brand_id==1){
          $type = Protype::orderBy('created_at','desc')->get();
        }else{
          $type = Protype::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        if(Auth::User()->brand_id==1){
            $contractor = Procontractor::orderBy('created_at','desc')->get();
          }else{
              $contractor = Procontractor::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
        if(Auth::User()->brand_id==1){
          $customer=Customer::get();
        }else{
          $customer=Customer::where('brid',Auth::User()->brand_id)->get(); 
        }
    	$project = Project::findOrFail($id);
    	return view('main.admin.manage_project.project_edit',compact('project','group','subgroup','type','contractor','customer'));
    }

    public function update_project(Request $request,$id)
    {
    	$request->validate([
            'project_id' => 'required'
        ]);

        $data = Project::findOrFail($id);
        $input['project_id'] =$request->project_id;
        $input['name'] = $request->name;
        $input['pgid'] = $request->pgid;
        $input['psgid'] = $request->psgid;
        $input['status'] = $request->status;
        $input['cperson'] = $request->cperson;
        $input['cnumber'] = $request->cnumber;
        $input['prjamount'] = $request->prjamount;
        $input['prjexamount'] = $request->prjexamount;
        $input['coid'] = $request->coid;
        $input['coamount'] = $request->coamount;
        $input['client'] = $request->client;
        $input['prjdetails'] = $request->prjdetails;
        $input['address'] = $request->address;
        $input['save_project'] = $request->save_project;
        // dd($input);
        $data->update($input);

        return Redirect::route('project-list-page')->withErrors(['Data Updated Successfully...!!!']);
    }

    public function project_destroy($id)
    {
        $data = Project::findOrFail($id);
        $data->delete();
        return Redirect::back()->withErrors(['Data Deleted Successfully...!!!']);
    } 
    public function show($id)
    {
      $projects=Project::with('customer')->findOrFail($id);
      // dd($projects->toArray());
        return view('main.admin.manage_project.project_view',compact('projects'));
    }
}
