<?php

namespace App\Http\Controllers\Project;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Datatables;
use App\Procontractor;
use Redirect;
Use Auth;

class procontractorController extends Controller
{
    public function create_project_contractor()
    {
        $results = 'CONT-NO-00' . Procontractor::get()->max('id');
    	return view('main.admin.manage_project.project_contractor_create',compact('results'));
    }
    public function list_project_contractor()
    {
        if(Auth::User()->brand_id==1){
    	  $datas = Procontractor::orderBy('created_at','desc')->get();
        //   dd($datas->toArray());
        }else{
            $datas = Procontractor::where('brid',Auth::User()->brand_id)->orderBy('created_at','desc')->get();
        }
    	return view('main.admin.manage_project.project_contractor_list',compact('datas'));
    }

    public function store_project_contractor(Request $request){
    	
        $request->validate([
            'code' => 'unique:procontractors|required',
            'name' => 'required'
        ]);

        $brid= Auth::User()->brand_id;
        $uid = Auth::User()->id;

        $data = new Procontractor();
        $input = $request->all();
        $input['brid']= $brid;
        $input['uid']= $uid;
        $data->fill($input)->save();
    	$datas = Procontractor::orderBy('created_at','desc')->get();
    	return view('main.admin.manage_project.project_contractor_list ',compact('datas'));
    }
    public function project_contractor_edit($id)
    {
    	$data = Procontractor::findOrFail($id);
    	return view('main.admin.manage_project.project_contractor_edit',compact('data'));
    }

    public function update_project_contractor(Request $request,$id)
    {
    	$request->validate([
            'name' => 'required',
            'code' => 'required'
        ]);

        $data = Procontractor::findOrFail($id);
        $input = $request->all();
        $data->update($input);

        return Redirect::route('project-contractor-list-page')->withErrors(['Data Updated Successfully...!!!']);
    }

    public function project_contractor_destroy($id)
    {
        $data = Procontractor::findOrFail($id);
        $data->delete();
        return Redirect::back()->withErrors(['Data Deleted Successfully...!!!']);
    } 
}
