<?php

namespace App\Http\Controllers\Client;

use App\Customer;
use App\District;
use App\Group;
use App\Http\Controllers\Controller;
use App\Zone;
use Illuminate\Http\Request;

use Auth;

class CustomerController extends Controller
{
    public function index()
    {
        if(Auth::User()->brand_id==1){
            $customers = Customer::with(['group','district','zone'])->get();
          }else{
            $customers = Customer::where('brid',Auth::User()->brand_id)->with(['group','district','zone'])->get();
          }
       
        return view('main.admin.client_setup.customer_list',compact('customers'));
    }
    public function create()
    {
        $groups = Group::get();
        $districts = District::get();
        $zones = Zone::get();
        $cus_track = 'CU-NO-' . Customer::get()->max('id');
        return view('main.admin.client_setup.customer_create',compact('groups','districts','zones','cus_track'));
    }

    public function store(Request $request)
    {
        $brid= Auth::User()->brand_id;
        $uid = Auth::User()->id;
        $data = new Customer();
        $input = $request->all();
        $input['uid']= $uid;
        $input['brid']= $brid;
        $data->fill($input)->save();
        return redirect(route('customer-list'));
    }
    public function edit($id)
    {
        $customer = Customer::find($id);
        $groups = Group::get();
        $districts = District::get();
        $zones = Zone::get();
        return view('main.admin.client_setup.customer_edit',compact('groups','districts','zones','customer'));
    }

    public function update(Request $request,$id)
    {
        $customer = Customer::findOrFail($id);
        $customer->update($request->all());
        return redirect(route('customer-list'));
    }
    public function destroy($id)
    {
        $customer = Customer::findOrFail($id);
        $customer->delete();
        // dd($group);
        return redirect(route('customer-list'))->with('messages','successfully');
    }
}
