<?php

namespace App\Http\Controllers\Client;

use App\C_Group;
use App\Http\Controllers\Controller;
use App\Product;
use App\Supplier;
use App\Zone;
use Illuminate\Http\Request;
use Auth;

class SupplierController extends Controller
{
    public function index()
    {
        if(Auth::User()->brand_id==1){
            $suppliers = Supplier::get();
        }else{
            $suppliers = Supplier::where('brid',Auth::User()->brand_id)->get();
        }
        return view('main.admin.client_setup.supplier_list',compact('suppliers'));
    }
    public function create()
    {
        $zones = Zone::get();
        $groups = C_Group::get();
        $sup_track = 'SU-NO-' . Supplier::get()->max('id');
        return view('main.admin.client_setup.supplier_create',compact('zones','groups','sup_track'));
    }

    public function store(Request $request)
    {
        $brid= Auth::User()->brand_id;
        $uid = Auth::User()->id;
        $data = new Supplier();
        $input = $request->all();
        $input['uid']= $uid;
        $input['brid']= $brid;
        $data->fill($input)->save();
        return redirect(route('supplier-list'))->with('messages','successfully');
    }

    public function edit($id)
    {
        $supplier = Supplier::find($id);
        $zones = Zone::get();
        $groups = C_Group::get();
        return view('main.admin.client_setup.supplier_edit',compact('supplier','zones','groups'));
    }
    public function update(Request $request,$id)
    {
        $supplier = Supplier::findOrFail($id);
        $supplier->update($request->all());
        return redirect(route('supplier-list'));
    }
    public function destroy($id)
    {
        $supplier = Supplier::findOrFail($id);
        $supplier->delete();
        // dd($group);
        return redirect(route('supplier-list'))->with('messages','successfully');
    }
}
