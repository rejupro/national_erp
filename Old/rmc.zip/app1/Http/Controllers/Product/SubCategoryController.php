<?php

namespace App\Http\Controllers\Product;

use App\Category;
use App\Http\Controllers\Controller;
use App\SubCategory;
use Illuminate\Http\Request;
use Auth;
class SubCategoryController extends Controller
{
    public function index()
    {
         if(Auth::User()->brand_id==1){
            $subcategorys = SubCategory::get();
         }else{
            $subcategorys = SubCategory::where('brid',Auth::User()->brand_id)->get();
         }
        // dd($subcategorys->toArray());
        return view('main.admin.productsetup.product_subcategory_list',compact('subcategorys'));
    }

    public function create()
    {
        if(Auth::User()->brand_id==1){
            $categorys = Category::get();
         }else{
            $categorys = Category::where('brid',Auth::User()->brand_id)->get();
         }
        return view('main.admin.productsetup.product_subcategory_create',compact('categorys'));
    }
    public function store(Request $request)
    {
        $brid= Auth::User()->brand_id;
        $uid = Auth::User()->id;
        $data = new SubCategory();
        $input = $request->all();
        $input['brid']= $brid;
        $input['uid']= $uid;
        $data->fill($input)->save();
        // dd($request->toArray());
        //SubCategory::create($request->all());
        return redirect(route('subcategory-create-route'));
    }
    public function edit($id)
    {
        if(Auth::User()->brand_id==1){
            $categorys = Category::get();
         }else{
            $categorys = Category::where('brid',Auth::User()->brand_id)->get();
         }
        $subcategory = SubCategory::find($id);
        // dd($subcategory->toArray());
        return view('main.admin.productsetup.product_subcategory_edit',compact('subcategory','categorys'));
    }
    public function update(Request $request,$id)
    {
        $subcategory = SubCategory::findOrFail($id);
        $subcategory->update($request->all());
        return redirect(route('subcategory-list'));
    }
    public function destroy($id)
    {
        $subcategory = Subcategory::findOrFail($id);
        $subcategory->delete();
        return redirect(route('subcategory-list'));
    }


}
