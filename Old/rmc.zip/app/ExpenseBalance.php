<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpenseBalance extends Model
{
    //
}
