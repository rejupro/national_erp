<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lc extends Model
{
    protected $table = 'lcs';
}
